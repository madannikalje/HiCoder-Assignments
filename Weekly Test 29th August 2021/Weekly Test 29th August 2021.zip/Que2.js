let sentence =  "JS is popular";

console.log(sentence.split(" ").reverse().join(" "))